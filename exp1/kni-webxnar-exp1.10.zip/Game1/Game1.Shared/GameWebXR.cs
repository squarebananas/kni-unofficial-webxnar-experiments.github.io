﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Input.Touch;
using Microsoft.Xna.Framework.Media;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Game1
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class GameWebXR : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        SpriteFont spriteFont;

        Texture2D groundTexture;
        Texture2D whitePixel;

        BasicEffect basicEffect;
        VertexPositionColor[] leftVertices;
        VertexPositionColor[] rightVertices;
        VertexPositionNormalTexture[] floorVertices;

        bool initialXRDone = false;
        bool initialDrawDone = false;

        public GameWebXR()
        {
            graphics = new GraphicsDeviceManager(this)
            {
                GraphicsProfile = GraphicsProfile.Reach,
                PreferredBackBufferFormat = SurfaceFormat.ColorSRgb
            };

            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();

            spriteFont = Content.Load<SpriteFont>("Font1");

            groundTexture = Content.Load<Texture2D>("Checker_0");

            whitePixel = new Texture2D(GraphicsDevice, 1, 1);
            whitePixel.SetData([Color.White]);

            basicEffect = new BasicEffect(GraphicsDevice);

            leftVertices = [
                new VertexPositionColor(new Vector3(0, 0, -1), Color.Yellow),
                new VertexPositionColor(new Vector3(-1, 1, 1), Color.Red),
                new VertexPositionColor(new Vector3(1, 1, 1), Color.Red),
                new VertexPositionColor(new Vector3(1, 1, 1), Color.Red),
                new VertexPositionColor(new Vector3(-1, 1, 1), Color.Red),
                new VertexPositionColor(new Vector3(0, 0, -1), Color.Yellow)];

            rightVertices = [
                new VertexPositionColor(new Vector3(0, 0, -1), Color.Yellow),
                new VertexPositionColor(new Vector3(-1, 1, 1), Color.Green),
                new VertexPositionColor(new Vector3(1, 1, 1), Color.Green),
                new VertexPositionColor(new Vector3(1, 1, 1), Color.Green),
                new VertexPositionColor(new Vector3(-1, 1, 1), Color.Green),
                new VertexPositionColor(new Vector3(0, 0, -1), Color.Yellow)];

            floorVertices = [
                new VertexPositionNormalTexture(new Vector3(-1, 0, -1), Vector3.Up, new Vector2(-10, -10)),
                new VertexPositionNormalTexture(new Vector3(1, 0, -1), Vector3.Up, new Vector2(10, -10)),
                new VertexPositionNormalTexture(new Vector3(-1, 0, 1), Vector3.Up, new Vector2(-10, 10)),
                new VertexPositionNormalTexture(new Vector3(1, 0, 1), Vector3.Up, new Vector2(10, 10))];

            nkast.Wasm.Dom.Navigator.GameDrawAction = DrawXR;
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            

            // TODO: Use this.Content to load your game content here
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        protected override void Update(GameTime gameTime)
        {
            MouseState mouseState = Mouse.GetState();
            KeyboardState keyboardState = Keyboard.GetState();
            GamePadState gamePadState = GamePad.GetState(PlayerIndex.One);

            if (keyboardState.IsKeyDown(Keys.Escape) ||
                keyboardState.IsKeyDown(Keys.Back) ||
                gamePadState.Buttons.Back == ButtonState.Pressed)
            {
                try { Exit(); }
                catch (PlatformNotSupportedException) { /* ignore */ }
            }

            UpdateWebXR(gameTime);

            base.Update(gameTime);
        }

        public void UpdateWebXR(GameTime gameTime)
        {
            if (gameTime.TotalGameTime.TotalSeconds >= 0.5d && initialXRDone == false)
            {
                nkast.Wasm.Dom.Window.Current.Navigator.GetIsSessionSupported();
                initialXRDone = true;
            }
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            if (initialDrawDone)
                return;

            GraphicsDevice.Clear(new Color(247, 209, 39));
            initialDrawDone = true;
        }

        public void DrawXR()
        {
            string combinedFrameData = nkast.Wasm.Dom.Window.Current.Navigator.GetCombinedFrameData();
            string[] data = combinedFrameData.Split('|');

            Matrix transform = StringToMatrix(data[0]);
            Matrix projection = StringToMatrix(data[1]);
            bool leftEye = data[2] == "left";

            spriteBatch.Begin(depthStencilState: DepthStencilState.None);
            spriteBatch.Draw(whitePixel, new Vector2(-1000, -1000), null, Color.CornflowerBlue, 0f, Vector2.Zero, 4000f, SpriteEffects.None, 0f);
            spriteBatch.End();
            GraphicsDevice.DepthStencilState = DepthStencilState.Default;

            if (data.Length >= 5)
            {
                basicEffect.VertexColorEnabled = true;
                basicEffect.TextureEnabled = false;
                basicEffect.LightingEnabled = false;
                basicEffect.View = Matrix.Invert(transform);
                basicEffect.Projection = projection;
                Matrix leftGrip = StringToMatrix(data[3]);
                Matrix rightGrip = StringToMatrix(data[4]);
                basicEffect.World = Matrix.CreateScale(0.05f) * leftGrip;
                basicEffect.CurrentTechnique.Passes[0].Apply();
                GraphicsDevice.DrawUserPrimitives(PrimitiveType.TriangleList, leftVertices, 0, 2);
                basicEffect.World = Matrix.CreateScale(0.05f) * rightGrip;
                basicEffect.CurrentTechnique.Passes[0].Apply();
                GraphicsDevice.DrawUserPrimitives(PrimitiveType.TriangleList, rightVertices, 0, 2);
            }

            basicEffect.VertexColorEnabled = false;
            basicEffect.TextureEnabled = true;
            basicEffect.Texture = groundTexture;
            basicEffect.World = Matrix.CreateScale(25f) * Matrix.CreateTranslation(0, -2, 0);
            basicEffect.View = Matrix.Invert(transform);
            basicEffect.Projection = projection;
            basicEffect.CurrentTechnique.Passes[0].Apply();
            GraphicsDevice.SamplerStates[0] = SamplerState.LinearWrap;
            GraphicsDevice.DrawUserPrimitives(PrimitiveType.TriangleStrip, floorVertices, 0, 2);

            GraphicsDevice.DepthStencilState = DepthStencilState.Default;
        }

        public Matrix StringToMatrix(string text)
        {
            try
            {
                string[] strs = text.Split(',');
                float[] fArray = new float[16];
                for (int i = 0; i < strs.Length; i++)
                    fArray[i] = float.Parse(strs[i]);

                Matrix projectionMatrix = new Matrix(
                    fArray[0], fArray[1], fArray[2], fArray[3],
                    fArray[4], fArray[5], fArray[6], fArray[7],
                    fArray[8], fArray[9], fArray[10], fArray[11],
                    fArray[12], fArray[13], fArray[14], fArray[15]);

                return projectionMatrix;
            }
            catch
            {
                return Matrix.Identity;
            }
        }
    }
}
