﻿using System;

namespace nkast.Wasm.Canvas
{
    public enum TextBaseline 
    { 
        Alphabetic = 1,
        Top = 2,
        Hanging = 3,
        Middle = 4,
        Ideographic = 5,
        Bottom = 6
    }
}
