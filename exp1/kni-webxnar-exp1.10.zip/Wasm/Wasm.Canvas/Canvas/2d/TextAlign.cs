﻿using System;

namespace nkast.Wasm.Canvas
{
    public enum TextAlign
    { 
        Start = 1,
        Left = 2,
        Right = 3,
        Center = 4,
        End = 5
    }
}
