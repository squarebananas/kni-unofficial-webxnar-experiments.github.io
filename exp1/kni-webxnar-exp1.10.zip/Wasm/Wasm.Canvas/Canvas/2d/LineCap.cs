﻿using System;

namespace nkast.Wasm.Canvas
{
    public enum LineCap
    { 
        Butt = 1,
        Round = 2,
        Square = 3
    }
}
