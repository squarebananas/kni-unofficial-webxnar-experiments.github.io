﻿namespace nkast.Wasm.Canvas.WebGL
{
    public enum WebGL2DrawBufferAttachmentPoint
    {
        NONE = 0x0000,
        BACK = 0x0405,

        COLOR_ATTACHMENT0 = 0x8CE0,
    }
}
