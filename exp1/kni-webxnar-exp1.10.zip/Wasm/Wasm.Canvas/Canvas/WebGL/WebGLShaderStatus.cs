﻿using System;

namespace nkast.Wasm.Canvas.WebGL
{
    public enum WebGLShaderStatus
    {
        DELETE  = 0x8B80,
        COMPILE = 0x8B81,
    }
}
