﻿using System;

namespace nkast.Wasm.Canvas.WebGL
{
    public enum WebGLEquationFunc
    {
        ADD                 = 0x8006,
        SUBTRACT            = 0x800A,
        REVERSE_SUBTRACT    = 0x800B,
    }
}
