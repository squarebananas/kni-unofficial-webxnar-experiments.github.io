﻿namespace nkast.Wasm.Canvas.WebGL
{
    public enum WebGLBufferType
    {
        ARRAY         = 0x8892,
        ELEMENT_ARRAY = 0x8893, // indices
    }
}