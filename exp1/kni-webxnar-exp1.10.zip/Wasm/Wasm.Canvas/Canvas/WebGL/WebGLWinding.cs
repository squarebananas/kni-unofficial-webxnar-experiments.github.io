﻿using System;

namespace nkast.Wasm.Canvas.WebGL
{
    public enum WebGLWinding
    {
        CW = 0x0900,
        CCW = 0x0901,
    }
}
