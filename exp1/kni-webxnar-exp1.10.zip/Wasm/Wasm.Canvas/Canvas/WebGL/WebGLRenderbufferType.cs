﻿namespace nkast.Wasm.Canvas.WebGL
{
    public enum WebGLRenderbufferType
    {
        RENDERBUFFER     = 0x8D41,
    }
}
