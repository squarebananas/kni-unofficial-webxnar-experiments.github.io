﻿using System;

namespace nkast.Wasm.Canvas.WebGL
{
    public enum WebGLCullFaceMode
    {
        FRONT           = 0x0404,
        BACK            = 0x0405,
        FRONT_AND_BACK  = 0x0408,
    }
}
