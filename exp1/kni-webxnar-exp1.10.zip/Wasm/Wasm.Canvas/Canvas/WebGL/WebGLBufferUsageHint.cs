﻿namespace nkast.Wasm.Canvas.WebGL
{
    public enum WebGLBufferUsageHint
    {
        STATIC_DRAW     = 0x88E4,
        STREAM_DRAW     = 0x88E0,
        DYNAMIC_DRAW    = 0x88E8,
    }
}