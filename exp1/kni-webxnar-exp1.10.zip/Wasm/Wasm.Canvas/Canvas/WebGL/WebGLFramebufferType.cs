﻿namespace nkast.Wasm.Canvas.WebGL
{
    public enum WebGLFramebufferType
    {
        FRAMEBUFFER     = 0x8D40,
    }
}
