﻿namespace nkast.Wasm.Canvas.WebGL
{
    public enum WebGLFramebufferAttachmentPoint
    {
        COLOR_ATTACHMENT0           = 0x8CE0,
        DEPTH_ATTACHMENT            = 0x8D00,
        STENCIL_ATTACHMENT          = 0x8D20,
        DEPTH_STENCIL_ATTACHMENT    = 0x821A,
    }
}
