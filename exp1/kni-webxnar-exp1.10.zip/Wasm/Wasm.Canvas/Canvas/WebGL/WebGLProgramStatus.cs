﻿using System;


namespace nkast.Wasm.Canvas.WebGL
{
    public enum WebGLProgramStatus
    {
        LINK        = 0x8B82,
        //DELETE      = 0x,
        //VALIDATE    = 0x,
    }
}
