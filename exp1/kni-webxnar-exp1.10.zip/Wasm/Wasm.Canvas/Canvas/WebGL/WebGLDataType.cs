﻿namespace nkast.Wasm.Canvas.WebGL
{
    public enum WebGLDataType
    {
        BYTE    = 0x1400,
        UBYTE   = 0x1401,
        SHORT   = 0x1402,
        USHORT  = 0x1403,
        INT     = 0x1404,
        UINT    = 0x1405,
        FLOAT   = 0x1406,
    }
}