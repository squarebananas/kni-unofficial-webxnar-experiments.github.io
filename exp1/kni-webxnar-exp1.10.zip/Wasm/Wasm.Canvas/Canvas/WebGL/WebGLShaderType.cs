﻿namespace nkast.Wasm.Canvas.WebGL
{
    public enum WebGLShaderType
    {
        VERTEX     = 0x8B31,
        FRAGMENT   = 0x8B30,
    }
}