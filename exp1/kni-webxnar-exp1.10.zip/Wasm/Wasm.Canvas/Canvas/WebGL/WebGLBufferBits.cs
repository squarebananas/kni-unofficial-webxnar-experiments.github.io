﻿namespace nkast.Wasm.Canvas.WebGL
{
    public enum WebGLBufferBits
    {
        COLOR   = 0x4000,
        DEPTH   = 0x0100,
        STENCIL = 0x0400,
    }
}