﻿using System.Numerics;

namespace Boids.Engine
{
    public struct TouchState
    {
        public Vector2 Position;
        internal bool IsPressed;
    }
}
