﻿using System;

namespace nkast.Wasm.Audio
{
    public enum ContextState
    {
        Suspended = 1,
        Running = 2,
        Closed = 3,
    }
}
