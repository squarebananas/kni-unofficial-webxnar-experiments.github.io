using System;
using System.Collections.Generic;
using System.Globalization;
using Microsoft.JSInterop.WebAssembly;

namespace nkast.Wasm.Dom
{
    public class Div : JSObject
    {
        internal Div(int uid) : base(uid)
        {
        }
    }
}
